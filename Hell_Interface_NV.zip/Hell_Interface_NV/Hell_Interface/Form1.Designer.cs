﻿namespace Hell_Interface
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LabelName = new System.Windows.Forms.Label();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.Age1 = new System.Windows.Forms.RadioButton();
            this.Age2 = new System.Windows.Forms.RadioButton();
            this.Age3 = new System.Windows.Forms.RadioButton();
            this.Age4 = new System.Windows.Forms.RadioButton();
            this.Age5 = new System.Windows.Forms.RadioButton();
            this.Age6 = new System.Windows.Forms.RadioButton();
            this.Age7 = new System.Windows.Forms.RadioButton();
            this.Age8 = new System.Windows.Forms.RadioButton();
            this.Age9 = new System.Windows.Forms.RadioButton();
            this.Age10 = new System.Windows.Forms.RadioButton();
            this.Age11 = new System.Windows.Forms.RadioButton();
            this.Age12 = new System.Windows.Forms.RadioButton();
            this.Age13 = new System.Windows.Forms.RadioButton();
            this.Age14 = new System.Windows.Forms.RadioButton();
            this.Age15 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxSkillsLabel = new System.Windows.Forms.TextBox();
            this.textBoxSkills = new System.Windows.Forms.TextBox();
            this.labelJob = new System.Windows.Forms.Label();
            this.checkBoxManager = new System.Windows.Forms.CheckBox();
            this.checkBoxJanitor = new System.Windows.Forms.CheckBox();
            this.checkBoxCEO = new System.Windows.Forms.CheckBox();
            this.checkBoxIntern = new System.Windows.Forms.CheckBox();
            this.buttonExit = new System.Windows.Forms.Button();
            this.buttonYes = new System.Windows.Forms.Button();
            this.buttonNext = new System.Windows.Forms.Button();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.labelPhone = new System.Windows.Forms.Label();
            this.labelEmail = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // LabelName
            // 
            this.LabelName.AutoSize = true;
            this.LabelName.Font = new System.Drawing.Font("Niagara Engraved", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelName.Location = new System.Drawing.Point(0, 3);
            this.LabelName.Name = "LabelName";
            this.LabelName.Size = new System.Drawing.Size(46, 23);
            this.LabelName.TabIndex = 0;
            this.LabelName.Text = "Name:";
            // 
            // textBoxName
            // 
            this.textBoxName.Font = new System.Drawing.Font("Mistral", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxName.Location = new System.Drawing.Point(52, 9);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(33, 17);
            this.textBoxName.TabIndex = 1;
            // 
            // Age1
            // 
            this.Age1.AutoSize = true;
            this.Age1.Location = new System.Drawing.Point(137, 9);
            this.Age1.Name = "Age1";
            this.Age1.Size = new System.Drawing.Size(37, 17);
            this.Age1.TabIndex = 2;
            this.Age1.TabStop = true;
            this.Age1.Text = "18";
            this.Age1.UseVisualStyleBackColor = true;
            this.Age1.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age2
            // 
            this.Age2.AutoSize = true;
            this.Age2.Location = new System.Drawing.Point(137, 32);
            this.Age2.Name = "Age2";
            this.Age2.Size = new System.Drawing.Size(37, 17);
            this.Age2.TabIndex = 3;
            this.Age2.TabStop = true;
            this.Age2.Text = "19";
            this.Age2.UseVisualStyleBackColor = true;
            this.Age2.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age3
            // 
            this.Age3.AutoSize = true;
            this.Age3.Location = new System.Drawing.Point(137, 55);
            this.Age3.Name = "Age3";
            this.Age3.Size = new System.Drawing.Size(37, 17);
            this.Age3.TabIndex = 4;
            this.Age3.TabStop = true;
            this.Age3.Text = "20";
            this.Age3.UseVisualStyleBackColor = true;
            this.Age3.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age4
            // 
            this.Age4.AutoSize = true;
            this.Age4.Location = new System.Drawing.Point(137, 78);
            this.Age4.Name = "Age4";
            this.Age4.Size = new System.Drawing.Size(37, 17);
            this.Age4.TabIndex = 5;
            this.Age4.TabStop = true;
            this.Age4.Text = "21";
            this.Age4.UseVisualStyleBackColor = true;
            this.Age4.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age5
            // 
            this.Age5.AutoSize = true;
            this.Age5.Location = new System.Drawing.Point(137, 101);
            this.Age5.Name = "Age5";
            this.Age5.Size = new System.Drawing.Size(37, 17);
            this.Age5.TabIndex = 6;
            this.Age5.TabStop = true;
            this.Age5.Text = "22";
            this.Age5.UseVisualStyleBackColor = true;
            this.Age5.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age6
            // 
            this.Age6.AutoSize = true;
            this.Age6.Location = new System.Drawing.Point(168, 9);
            this.Age6.Name = "Age6";
            this.Age6.Size = new System.Drawing.Size(37, 17);
            this.Age6.TabIndex = 7;
            this.Age6.TabStop = true;
            this.Age6.Text = "24";
            this.Age6.UseVisualStyleBackColor = true;
            this.Age6.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age7
            // 
            this.Age7.AutoSize = true;
            this.Age7.Location = new System.Drawing.Point(168, 32);
            this.Age7.Name = "Age7";
            this.Age7.Size = new System.Drawing.Size(37, 17);
            this.Age7.TabIndex = 8;
            this.Age7.TabStop = true;
            this.Age7.Text = "17";
            this.Age7.UseVisualStyleBackColor = true;
            this.Age7.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age8
            // 
            this.Age8.AutoSize = true;
            this.Age8.Location = new System.Drawing.Point(168, 55);
            this.Age8.Name = "Age8";
            this.Age8.Size = new System.Drawing.Size(37, 17);
            this.Age8.TabIndex = 9;
            this.Age8.TabStop = true;
            this.Age8.Text = "25";
            this.Age8.UseVisualStyleBackColor = true;
            this.Age8.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age9
            // 
            this.Age9.AutoSize = true;
            this.Age9.Location = new System.Drawing.Point(168, 78);
            this.Age9.Name = "Age9";
            this.Age9.Size = new System.Drawing.Size(37, 17);
            this.Age9.TabIndex = 10;
            this.Age9.TabStop = true;
            this.Age9.Text = "26";
            this.Age9.UseVisualStyleBackColor = true;
            this.Age9.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age10
            // 
            this.Age10.AutoSize = true;
            this.Age10.Location = new System.Drawing.Point(168, 101);
            this.Age10.Name = "Age10";
            this.Age10.Size = new System.Drawing.Size(37, 17);
            this.Age10.TabIndex = 11;
            this.Age10.TabStop = true;
            this.Age10.Text = "27";
            this.Age10.UseVisualStyleBackColor = true;
            this.Age10.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age11
            // 
            this.Age11.AutoSize = true;
            this.Age11.Location = new System.Drawing.Point(200, 9);
            this.Age11.Name = "Age11";
            this.Age11.Size = new System.Drawing.Size(37, 17);
            this.Age11.TabIndex = 12;
            this.Age11.TabStop = true;
            this.Age11.Text = "31";
            this.Age11.UseVisualStyleBackColor = true;
            this.Age11.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age12
            // 
            this.Age12.AutoSize = true;
            this.Age12.Location = new System.Drawing.Point(200, 32);
            this.Age12.Name = "Age12";
            this.Age12.Size = new System.Drawing.Size(37, 17);
            this.Age12.TabIndex = 13;
            this.Age12.TabStop = true;
            this.Age12.Text = "33";
            this.Age12.UseVisualStyleBackColor = true;
            this.Age12.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age13
            // 
            this.Age13.AutoSize = true;
            this.Age13.Location = new System.Drawing.Point(200, 55);
            this.Age13.Name = "Age13";
            this.Age13.Size = new System.Drawing.Size(37, 17);
            this.Age13.TabIndex = 14;
            this.Age13.TabStop = true;
            this.Age13.Text = "32";
            this.Age13.UseVisualStyleBackColor = true;
            this.Age13.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age14
            // 
            this.Age14.AutoSize = true;
            this.Age14.Location = new System.Drawing.Point(200, 78);
            this.Age14.Name = "Age14";
            this.Age14.Size = new System.Drawing.Size(37, 17);
            this.Age14.TabIndex = 15;
            this.Age14.TabStop = true;
            this.Age14.Text = "34";
            this.Age14.UseVisualStyleBackColor = true;
            this.Age14.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // Age15
            // 
            this.Age15.AutoSize = true;
            this.Age15.Location = new System.Drawing.Point(200, 101);
            this.Age15.Name = "Age15";
            this.Age15.Size = new System.Drawing.Size(37, 17);
            this.Age15.TabIndex = 16;
            this.Age15.TabStop = true;
            this.Age15.Text = "42";
            this.Age15.UseVisualStyleBackColor = true;
            this.Age15.CheckedChanged += new System.EventHandler(this.Age_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Niagara Engraved", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(94, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 23);
            this.label1.TabIndex = 17;
            this.label1.Text = "Age:";
            // 
            // textBoxSkillsLabel
            // 
            this.textBoxSkillsLabel.Font = new System.Drawing.Font("Niagara Engraved", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSkillsLabel.Location = new System.Drawing.Point(3, 32);
            this.textBoxSkillsLabel.Name = "textBoxSkillsLabel";
            this.textBoxSkillsLabel.ReadOnly = true;
            this.textBoxSkillsLabel.Size = new System.Drawing.Size(43, 30);
            this.textBoxSkillsLabel.TabIndex = 18;
            this.textBoxSkillsLabel.Text = "Skills:";
            // 
            // textBoxSkills
            // 
            this.textBoxSkills.Font = new System.Drawing.Font("Mistral", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSkills.Location = new System.Drawing.Point(52, 32);
            this.textBoxSkills.Multiline = true;
            this.textBoxSkills.Name = "textBoxSkills";
            this.textBoxSkills.Size = new System.Drawing.Size(79, 86);
            this.textBoxSkills.TabIndex = 19;
            this.textBoxSkills.TextChanged += new System.EventHandler(this.textBoxSkills_TextChanged);
            // 
            // labelJob
            // 
            this.labelJob.AutoSize = true;
            this.labelJob.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelJob.Location = new System.Drawing.Point(233, 0);
            this.labelJob.Name = "labelJob";
            this.labelJob.Size = new System.Drawing.Size(140, 28);
            this.labelJob.TabIndex = 21;
            this.labelJob.Text = "Job Wanted";
            // 
            // checkBoxManager
            // 
            this.checkBoxManager.AutoSize = true;
            this.checkBoxManager.Location = new System.Drawing.Point(238, 32);
            this.checkBoxManager.Name = "checkBoxManager";
            this.checkBoxManager.Size = new System.Drawing.Size(68, 17);
            this.checkBoxManager.TabIndex = 22;
            this.checkBoxManager.Text = "Manager";
            this.checkBoxManager.UseVisualStyleBackColor = true;
            this.checkBoxManager.CheckedChanged += new System.EventHandler(this.checkBox_EnabledChanged);
            // 
            // checkBoxJanitor
            // 
            this.checkBoxJanitor.AutoSize = true;
            this.checkBoxJanitor.Location = new System.Drawing.Point(238, 55);
            this.checkBoxJanitor.Name = "checkBoxJanitor";
            this.checkBoxJanitor.Size = new System.Drawing.Size(57, 17);
            this.checkBoxJanitor.TabIndex = 23;
            this.checkBoxJanitor.Text = "Janitor";
            this.checkBoxJanitor.UseVisualStyleBackColor = true;
            this.checkBoxJanitor.CheckedChanged += new System.EventHandler(this.checkBox_EnabledChanged);
            // 
            // checkBoxCEO
            // 
            this.checkBoxCEO.AutoSize = true;
            this.checkBoxCEO.Location = new System.Drawing.Point(238, 78);
            this.checkBoxCEO.Name = "checkBoxCEO";
            this.checkBoxCEO.Size = new System.Drawing.Size(48, 17);
            this.checkBoxCEO.TabIndex = 24;
            this.checkBoxCEO.Text = "CEO";
            this.checkBoxCEO.UseVisualStyleBackColor = true;
            this.checkBoxCEO.CheckedChanged += new System.EventHandler(this.checkBox_EnabledChanged);
            // 
            // checkBoxIntern
            // 
            this.checkBoxIntern.AutoSize = true;
            this.checkBoxIntern.Location = new System.Drawing.Point(238, 101);
            this.checkBoxIntern.Name = "checkBoxIntern";
            this.checkBoxIntern.Size = new System.Drawing.Size(90, 17);
            this.checkBoxIntern.TabIndex = 25;
            this.checkBoxIntern.Text = "Unpaid Intern";
            this.checkBoxIntern.UseVisualStyleBackColor = true;
            this.checkBoxIntern.CheckedChanged += new System.EventHandler(this.checkBox_EnabledChanged);
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonExit.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.Location = new System.Drawing.Point(12, 169);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(90, 60);
            this.buttonExit.TabIndex = 26;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = false;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // buttonYes
            // 
            this.buttonYes.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonYes.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonYes.Location = new System.Drawing.Point(137, 168);
            this.buttonYes.Name = "buttonYes";
            this.buttonYes.Size = new System.Drawing.Size(90, 60);
            this.buttonYes.TabIndex = 27;
            this.buttonYes.Text = "Yes";
            this.buttonYes.UseVisualStyleBackColor = false;
            this.buttonYes.Click += new System.EventHandler(this.buttonYes_Click);
            // 
            // buttonNext
            // 
            this.buttonNext.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.buttonNext.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonNext.Location = new System.Drawing.Point(258, 168);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(90, 60);
            this.buttonNext.TabIndex = 28;
            this.buttonNext.Text = "Next";
            this.buttonNext.UseVisualStyleBackColor = false;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(-2, 143);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.ReadOnly = true;
            this.numericUpDown1.Size = new System.Drawing.Size(176, 20);
            this.numericUpDown1.TabIndex = 29;
            // 
            // labelPhone
            // 
            this.labelPhone.AutoSize = true;
            this.labelPhone.Font = new System.Drawing.Font("Monotype Corsiva", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelPhone.Location = new System.Drawing.Point(-5, 121);
            this.labelPhone.Name = "labelPhone";
            this.labelPhone.Size = new System.Drawing.Size(183, 18);
            this.labelPhone.TabIndex = 30;
            this.labelPhone.Text = "Enter your phone number:";
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.Font = new System.Drawing.Font("Comic Sans MS", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.Location = new System.Drawing.Point(180, 116);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(145, 23);
            this.labelEmail.TabIndex = 31;
            this.labelEmail.Text = "Enter your email:";
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(184, 142);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.ReadOnly = true;
            this.textBoxEmail.Size = new System.Drawing.Size(150, 20);
            this.textBoxEmail.TabIndex = 32;
            this.textBoxEmail.Text = "Mail@mail.mail";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(360, 231);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelPhone);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.buttonNext);
            this.Controls.Add(this.buttonYes);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.checkBoxIntern);
            this.Controls.Add(this.checkBoxCEO);
            this.Controls.Add(this.checkBoxJanitor);
            this.Controls.Add(this.checkBoxManager);
            this.Controls.Add(this.labelJob);
            this.Controls.Add(this.textBoxSkills);
            this.Controls.Add(this.textBoxSkillsLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Age15);
            this.Controls.Add(this.Age14);
            this.Controls.Add(this.Age13);
            this.Controls.Add(this.Age12);
            this.Controls.Add(this.Age11);
            this.Controls.Add(this.Age10);
            this.Controls.Add(this.Age9);
            this.Controls.Add(this.Age8);
            this.Controls.Add(this.Age7);
            this.Controls.Add(this.Age6);
            this.Controls.Add(this.Age5);
            this.Controls.Add(this.Age4);
            this.Controls.Add(this.Age3);
            this.Controls.Add(this.Age2);
            this.Controls.Add(this.Age1);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.LabelName);
            this.Name = "Form1";
            this.Text = "Job Application";
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label LabelName;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.RadioButton Age1;
        private System.Windows.Forms.RadioButton Age2;
        private System.Windows.Forms.RadioButton Age3;
        private System.Windows.Forms.RadioButton Age4;
        private System.Windows.Forms.RadioButton Age5;
        private System.Windows.Forms.RadioButton Age6;
        private System.Windows.Forms.RadioButton Age7;
        private System.Windows.Forms.RadioButton Age8;
        private System.Windows.Forms.RadioButton Age9;
        private System.Windows.Forms.RadioButton Age10;
        private System.Windows.Forms.RadioButton Age11;
        private System.Windows.Forms.RadioButton Age12;
        private System.Windows.Forms.RadioButton Age13;
        private System.Windows.Forms.RadioButton Age14;
        private System.Windows.Forms.RadioButton Age15;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxSkillsLabel;
        private System.Windows.Forms.TextBox textBoxSkills;
        private System.Windows.Forms.Label labelJob;
        private System.Windows.Forms.CheckBox checkBoxManager;
        private System.Windows.Forms.CheckBox checkBoxJanitor;
        private System.Windows.Forms.CheckBox checkBoxCEO;
        private System.Windows.Forms.CheckBox checkBoxIntern;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Button buttonYes;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label labelPhone;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.TextBox textBoxEmail;
    }
}

